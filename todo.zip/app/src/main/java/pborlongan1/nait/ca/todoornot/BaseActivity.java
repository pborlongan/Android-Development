package pborlongan1.nait.ca.todoornot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Pat on 2019-03-25.
 */

public class BaseActivity extends AppCompatActivity
{
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        super.onCreate(savedInstanceState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = this.getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.menu_item_view_archived:
            {
                startActivity(new Intent(this,CustomRow.class));
                break;
            }
            case R.id.menu_item_preferences:
            {
                startActivity(new Intent(this, PrefsActivity.class));
                break;
            }
        }
        return true;
    }

}
