package pborlongan1.nait.ca.todoornot;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


/**
 * Created by Pat on 2019-03-07.
 */

public class DBManager extends SQLiteOpenHelper
{
    static final String DB_NAME = "todolist.db";
    static final int DB_VERSION = 1;

    static final String LIST_NAME_TABLE = "listNames";
    static final String ITEM_TABLE = "listItems";

    static final String C_LIST_ID = BaseColumns._ID;
    static final String C_LISTNAME = "list_name";

    static final String C_ITEM_ID = BaseColumns._ID;
    static final String C_ITEM = "list_item";
    static final String C_DESCRIPTION = "description";
    static final String C_DATE = "created_date";
    static final String C_COMPLETED = "completed";
    static final String C_ITEM_LIST_NAME_ID = "list_name_id";

    public DBManager(Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database)
    {
        String listTable = "create table " + LIST_NAME_TABLE + " (" + C_LIST_ID + " integer primary key autoincrement, " + C_LISTNAME + " text);";
        String listItem = String.format("CREATE TABLE %s (%s INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT, %s TEXT, %s TEXT, %s TEXT, %s integer);", ITEM_TABLE, C_ITEM_ID, C_ITEM, C_DESCRIPTION, C_DATE, C_COMPLETED, C_ITEM_LIST_NAME_ID);

        database.execSQL(listTable);
        database.execSQL(listItem);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion)
    {
        database.execSQL("drop table if exists " + LIST_NAME_TABLE);
        database.execSQL("drop table if exists " + ITEM_TABLE);
        onCreate(database);
    }
}
