package pborlongan1.nait.ca.todoornot;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by Pat on 2019-03-07.
 */

public class MainActivity extends BaseActivity implements View.OnClickListener, SharedPreferences.OnSharedPreferenceChangeListener
{
    DBManager manager;
    SQLiteDatabase database;
    Cursor cursor;
    Spinner spinListNames;
    int currentListIndex = 0;
    int itemID = 0;
    ArrayAdapter<String> itemIds;
    ListViewAdapter lvAdapter;
    ListView lv_item;

    SharedPreferences prefs;
    View mainView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button createListButton = (Button) findViewById(R.id.button_create_list);
        createListButton.setOnClickListener(this);

        Button addItemButton = (Button) findViewById(R.id.button_add_item);
        addItemButton.setOnClickListener(this);

        Button updateItemButton = (Button)findViewById(R.id.button_update_item);
        updateItemButton.setOnClickListener(this);

        Button deleteItemButton = (Button)findViewById(R.id.button_delete_item);
        deleteItemButton.setOnClickListener(this);

        Button archiveItemButton = (Button)findViewById(R.id.button_archive_item);
        archiveItemButton.setOnClickListener(this);

        manager = new DBManager(this);
        database = manager.getReadableDatabase();

        spinListNames = (Spinner)findViewById(R.id.spin_list_names);
        lv_item = (ListView)findViewById(R.id.lv_list_items);

        PopulateListNames();
        spinListNames.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int index, long row) {
                currentListIndex = index;
                PopulateItemList(currentListIndex);
                lv_item.setOnItemClickListener(new AdapterView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long row) {
                        itemID = Integer.parseInt(itemIds.getItem(position));
                        GetItemData(itemID);
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //do nothing
            }
        });

        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.registerOnSharedPreferenceChangeListener(this);

        mainView = findViewById(R.id.main_layout);
        String bgColor = prefs.getString("main_bg_color", "#ddbbbb");

        int setText = Integer.parseInt(prefs.getString("text_size", "15"));
        createListButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, setText);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(bgColor));
        }

    }

    private void GetItemData(int itemID)
    {
        cursor = database.query(DBManager.ITEM_TABLE, null, DBManager.C_ITEM_ID + "=" + itemID, null, null, null, DBManager.C_ITEM_ID + " DESC");
        this.startManagingCursor(cursor);

        String itemName, itemDescription, itemCompleted, itemDate;
        EditText etItemName = (EditText)findViewById(R.id.et_item_name);
        EditText etItemDesc = (EditText)findViewById(R.id.et_item_description);
        EditText etItemDate = (EditText)findViewById(R.id.et_item_date);
        CheckBox cbCompleted = (CheckBox)findViewById(R.id.checkbox_completed);

        while(cursor.moveToNext())
        {
            itemName = cursor.getString(cursor.getColumnIndex(DBManager.C_ITEM));
            itemDescription = cursor.getString(cursor.getColumnIndex(DBManager.C_DESCRIPTION));
            itemCompleted = cursor.getString(cursor.getColumnIndex(DBManager.C_COMPLETED));
            itemDate = cursor.getString(cursor.getColumnIndex(DBManager.C_DATE));

            etItemName.setText(itemName);
            etItemDesc.setText(itemDescription);
            if(itemCompleted.equals("1"))
            {
                cbCompleted.setChecked(true);
            }
            else
            {
                cbCompleted.setChecked(false);
            }
            etItemDate.setText(itemDate);
        }

    }

    private void PopulateListNames()
    {
        cursor = database.query(DBManager.LIST_NAME_TABLE, null, null, null, null, null, DBManager.C_LIST_ID + " ASC");
        this.startManagingCursor(cursor);

        String listName, output;

        List<String> spinnerArray =  new ArrayList<String>();

        while(cursor.moveToNext())
        {
            listName = cursor.getString(cursor.getColumnIndex(DBManager.C_LISTNAME));

            output = String.format("%s", listName);
            spinnerArray.add(output);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinListNames.setAdapter(adapter);
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.button_create_list:
            {
                EditText text = (EditText)findViewById(R.id.et_list_name);
                String data = text.getText().toString();
                if(data.isEmpty())
                {
                    Toast.makeText(this, "List name can't be empty", Toast.LENGTH_LONG).show();
                }
                else
                {
                    PostToList(data);
                    text.setText("");
                    PopulateListNames();
                }

                break;
            }
            case R.id.button_add_item:
            {
                EditText item_name = (EditText)findViewById(R.id.et_item_name);
                EditText item_description = (EditText)findViewById(R.id.et_item_description);
                CheckBox checkBox = (CheckBox)findViewById(R.id.checkbox_completed);
                EditText item_date = (EditText)findViewById(R.id.et_item_date);

                String item = item_name.getText().toString();
                String description = item_description.getText().toString();
                String date = new SimpleDateFormat("MMMM dd yyyy", Locale.getDefault()).format(new Date());
                String checkBoxCompleted = "";

                if(item.isEmpty())
                {
                    Toast.makeText(this, "Item name can't be empty", Toast.LENGTH_LONG).show();
                }
                else
                {

                    if (checkBox.isChecked()) {
                        checkBoxCompleted = "1";
                    } else {
                        checkBoxCompleted = "0";
                    }
                    PostToListItem(item, description, date, checkBoxCompleted, currentListIndex);
                    item_name.setText("");
                    item_description.setText("");
                    item_date.setText("");
                    checkBox.setChecked(false);
                    PopulateItemList(currentListIndex);
                }
                break;
            }

            case R.id.button_update_item:
            {
                UpdateItem(itemID, currentListIndex);
                break;
            }

            case R.id.button_delete_item:
            {
                DeleteItem(itemID,currentListIndex);
                break;
            }

            case R.id.button_archive_item:
            {
                new ArchiveItem(true).execute();
                DeleteItem(itemID,currentListIndex);
                break;
            }
        }

    }

    private class ArchiveItem extends AsyncTask <String, Void, String>
    {
        String title;
        String item;
        String date;
        String checkBoxCompleted;

        public ArchiveItem(boolean showLoading)
        {
            super();
            EditText item_name = (EditText)findViewById(R.id.et_item_name);
            CheckBox checkBox = (CheckBox)findViewById(R.id.checkbox_completed);
            EditText item_date = (EditText)findViewById(R.id.et_item_date);

            title = spinListNames.getSelectedItem().toString();
            item = item_name.getText().toString();
            date = item_date.getText().toString();
            checkBoxCompleted = "";

            if (checkBox.isChecked()) {
                checkBoxCompleted = "1";
            } else {
                checkBoxCompleted = "0";
            }
        }

        @Override
        protected String doInBackground(String... strings)
        {
            String username = prefs.getString("login_name","patricia");
            String password = prefs.getString("login_password", "whoops");

            try
            {
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost("http://www.youcode.ca/Lab02Post.jsp");

                List<NameValuePair> postParameters = new ArrayList<NameValuePair>();
                postParameters.add(new BasicNameValuePair("LIST_TITLE", title));
                postParameters.add(new BasicNameValuePair("CONTENT", item));
                postParameters.add(new BasicNameValuePair("COMPLETED_FLAG", checkBoxCompleted));
                postParameters.add(new BasicNameValuePair("ALIAS", username));
                postParameters.add(new BasicNameValuePair("PASSWORD", password));
                postParameters.add(new BasicNameValuePair("CREATED_DATE", date));

                UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(postParameters);

                post.setEntity(formEntity);
                client.execute(post);
            }
            catch(Exception e)
            {
            }
            return null;
        }
    }

    private void DeleteItem(int itemID, int currentListIndex)
    {
        EditText item_name = (EditText)findViewById(R.id.et_item_name);
        EditText item_description = (EditText)findViewById(R.id.et_item_description);
        CheckBox checkBox = (CheckBox)findViewById(R.id.checkbox_completed);
        EditText item_date = (EditText)findViewById(R.id.et_item_date);

        database = manager.getReadableDatabase();
        database.delete(DBManager.ITEM_TABLE, "_id=" + itemID, null);

        item_name.setText("");
        item_description.setText("");
        item_date.setText("");
        checkBox.setChecked(false);
        PopulateItemList(currentListIndex);
    }


    private void UpdateItem(int itemID, int listNameIndex)
    {
        EditText item_name = (EditText)findViewById(R.id.et_item_name);
        EditText item_description = (EditText)findViewById(R.id.et_item_description);
        CheckBox checkBox = (CheckBox)findViewById(R.id.checkbox_completed);
        EditText item_date = (EditText)findViewById(R.id.et_item_date);

        String item = item_name.getText().toString();
        String description = item_description.getText().toString();
        String date = item_date.getText().toString();
        String checkBoxCompleted = "";

        if(item.isEmpty())
        {
            Toast.makeText(this, "Item name can't be empty", Toast.LENGTH_LONG).show();
        }
        else if(itemID == 0)
        {
            Toast.makeText(this, "Select an item", Toast.LENGTH_LONG).show();
        }
        else
        {
            if (checkBox.isChecked()) {
                checkBoxCompleted = "1";
            } else {
                checkBoxCompleted = "0";
            }

            database = manager.getReadableDatabase();
            ContentValues value = new ContentValues();

            value.put(DBManager.C_ITEM, item);
            value.put(DBManager.C_DESCRIPTION, description);
            value.put(DBManager.C_COMPLETED, checkBoxCompleted);
            value.put(DBManager.C_DATE, date);
            value.put(DBManager.C_ITEM_LIST_NAME_ID, listNameIndex);
            database.update(DBManager.ITEM_TABLE, value, "_id=" + itemID, null);

            item_name.setText("");
            item_description.setText("");
            item_date.setText("");
            checkBox.setChecked(false);
            PopulateItemList(currentListIndex);
        }
    }

    private void PopulateItemList(int id)
    {
        cursor = database.query(DBManager.ITEM_TABLE, null, DBManager.C_ITEM_LIST_NAME_ID + "=" + id, null, null, null, DBManager.C_ITEM_ID + " DESC");
        this.startManagingCursor(cursor);

        String itemName, itemIndexID, output;

        List<String> items =  new ArrayList<String>();
        List<String> ids = new ArrayList<String>();

        while(cursor.moveToNext())
        {
            itemName = cursor.getString(cursor.getColumnIndex(DBManager.C_ITEM));
            itemIndexID = cursor.getString(cursor.getColumnIndex(DBManager.C_LIST_ID));
            output = String.format("%s", itemName);
            items.add(output);
            ids.add(itemIndexID);
        }
        itemIds = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ids);
        lvAdapter = new ListViewAdapter(this, cursor);
        lv_item.setAdapter(lvAdapter);
    }

    private void PostToListItem(String itemName, String itemDescription, String date, String completed, int listNameIndex)
    {
        try
        {
            database = manager.getReadableDatabase();
            ContentValues value = new ContentValues();

            value.put(DBManager.C_ITEM, itemName);
            value.put(DBManager.C_DESCRIPTION, itemDescription);
            value.put(DBManager.C_COMPLETED, completed);
            value.put(DBManager.C_DATE, date);
            value.put(DBManager.C_ITEM_LIST_NAME_ID, listNameIndex);
            database.insert(DBManager.ITEM_TABLE, null, value);
        }
        catch (Exception e)
        {
            Toast.makeText(this, "Error: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void PostToList(String data)
    {
        try
        {
            database = manager.getReadableDatabase();
            ContentValues value = new ContentValues();

            value.put(DBManager.C_LISTNAME, data);
            database.insert(DBManager.LIST_NAME_TABLE, null, value);
        }
        catch (Exception e)
        {
            Toast.makeText(this, "Error: " + e, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        String bgColor = prefs.getString("main_bg_color", "#ddbbbb");
        mainView.setBackgroundColor(Color.parseColor(bgColor));

        Button createListButton = (Button) findViewById(R.id.button_create_list);
        int setText = Integer.parseInt(prefs.getString("text_size", "15"));
        createListButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, setText);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            ActionBar bar = this.getSupportActionBar();
            bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor(bgColor)));

            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor(bgColor));
        }
    }

}
