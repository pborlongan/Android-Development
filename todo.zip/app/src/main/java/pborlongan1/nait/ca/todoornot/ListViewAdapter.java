package pborlongan1.nait.ca.todoornot;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

/**
 * Created by pborlongan1 on 2/12/2019.
 */

public class ListViewAdapter extends SimpleCursorAdapter
{
    static final String[] columns = {DBManager.C_ITEM, DBManager.C_DATE, DBManager.C_DESCRIPTION, DBManager.C_COMPLETED};
    static final int[] ids = {R.id.tv_itemName, R.id.tv_itemDate, R.id.tv_itemDesc, R.id.tv_itemCompleted};

    public ListViewAdapter(Context context, Cursor cursor)
    {
        super(context, R.layout.listview_row, cursor, columns, ids);
    }

    @Override
    public void bindView(View row, Context context, Cursor cursor)
    {
        super.bindView(row, context, cursor);
    }
}
