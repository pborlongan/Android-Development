package pborlongan1.nait.ca.todoornot;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

public class CustomRow extends AppCompatActivity
{
    ProgressDialog pd;
    ArrayList<HashMap<String,String>> archivedItem = new ArrayList<HashMap<String, String>>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_row);

        pd = ProgressDialog.show(this, "","Retrieving items...");
        new FeedReader().execute("");
    }

    class FeedReader extends AsyncTask<String,Void,String>
    {
        SharedPreferences prefs;

        @Override
        protected void onPostExecute(String s)
        {
            pd.dismiss();
            String[] keys = new String[]{"post_date", "list_title", "content", "completed"};
            int[] ids = new int[]{R.id.row_date, R.id.row_title, R.id.row_content, R.id.row_completed};

            SimpleAdapter adapter = new SimpleAdapter(CustomRow.this, archivedItem, R.layout.custom_row_layout, keys, ids);
            ListView listView = (ListView)findViewById(R.id.list_custom);
            listView.setAdapter(adapter);
        }

        @Override
        protected String doInBackground(String... strings)
        {
            BufferedReader in = null;

            try
            {
            String username = prefs.getString("login_name","patricia");
            String password = prefs.getString("login_password", "whoops");

            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            request.setURI(new URI("http://www.youcode.ca/Lab02Get.jsp?ALIAS=patricia&PASSWORD=whoops"));

            HttpResponse response = client.execute(request);
            in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

            String field = "";

            while((field = in.readLine()) != null)
            {
                HashMap<String, String> temp = new HashMap<String, String>();

                temp.put("post_date", field);

                field = in.readLine();
                temp.put("list_title", field);

                field = in.readLine();
                temp.put("content", field);

                field = in.readLine();
                temp.put("completed", field);

                archivedItem.add(temp);
            }

            in.close();
        }
        catch(Exception ex)
        {
        }
            return null;
        }
    }

}
