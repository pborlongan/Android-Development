package ca.nait.pborlongan1.week05;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ChatterListActivity extends BaseActivity
{
    ListViewAdapter adapter;
    ListView listView;
    Cursor cursor;
    SQLiteDatabase database;
    DBManager manager;

    NewMessageReceiver receiver;
    IntentFilter filter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatter_list);
        listView = (ListView)findViewById(R.id.lv_chatter);
        manager = new DBManager(this);
        database = manager.getReadableDatabase();

        receiver = new NewMessageReceiver();
        filter = new IntentFilter(GetterService.NEW_MESSAGE);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        unregisterReceiver(receiver);
    }

    @Override
    protected void onResume()
    {
        cursor = database.query(DBManager.TABLE_NAME, null, null, null, null, null, DBManager.C_ID + " DESC");
        startManagingCursor(cursor);
        adapter = new ListViewAdapter(this, cursor);
        listView.setAdapter(adapter);

        registerReceiver(receiver,filter);

        super.onResume();
    }

    class NewMessageReceiver extends BroadcastReceiver
    {

        @Override
        public void onReceive(Context context, Intent intent)
        {
            cursor.requery();
            adapter.notifyDataSetChanged();
        }
    }


}
