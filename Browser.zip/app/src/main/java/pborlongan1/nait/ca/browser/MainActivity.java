package pborlongan1.nait.ca.browser;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    private Button buttonTargetA, buttonTargetB, buttonTargetC;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        final Context context = this;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonTargetA = (Button)findViewById(R.id.button_target_a);

        buttonTargetA.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(context, WebViewActivity.class);
                startActivity(intent);
            }
        });


        buttonTargetB = (Button)findViewById(R.id.button_target_b);
        buttonTargetB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                WebView webView = (WebView)findViewById(R.id.webview_a);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl("http://www.google.com");
            }
        });

        buttonTargetC = (Button)findViewById(R.id.button_target_c);
        buttonTargetC.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                WebView webView = (WebView)findViewById(R.id.webview_a);
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl("http://www.youtube.com/funhaus");
            }
        });
    }
}
