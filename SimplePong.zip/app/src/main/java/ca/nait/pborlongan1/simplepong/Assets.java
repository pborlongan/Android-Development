package ca.nait.pborlongan1.simplepong;

import ca.youcode.nait.games.Pixmap;

/**
 * Created by pborlongan1 on 3/19/2019.
 */

public class Assets
{
    public static Pixmap ball;
    public static Pixmap background;
    public static Pixmap paddle;
    public static Pixmap gameover;


}
