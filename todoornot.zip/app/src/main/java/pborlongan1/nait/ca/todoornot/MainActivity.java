package pborlongan1.nait.ca.todoornot;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Pat on 2019-03-07.
 */

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    DBManager manager;
    SQLiteDatabase database;
    Cursor cursor;
    TextView tvListNames;
    Spinner spinListNames;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        Button createListButton = (Button) findViewById(R.id.button_create_list);
        createListButton.setOnClickListener(this);

        manager = new DBManager(this);
        database = manager.getReadableDatabase();
        tvListNames = (TextView)findViewById(R.id.tv_list_names);
        spinListNames = (Spinner)findViewById(R.id.spin_list_names);

        PopulateListNames();
    }

    private void PopulateListNames()
    {
        tvListNames.setText("");

        cursor = database.query(DBManager.LIST_NAME_TABLE, null, null, null, null, null, DBManager.C_LIST_ID + " ASC");
        this.startManagingCursor(cursor);

        String id, listName, output;

        // you need to have a list of data that you want the spinner to display
        List<String> spinnerArray =  new ArrayList<String>();

        while(cursor.moveToNext())
        {
            id = cursor.getString(cursor.getColumnIndex(DBManager.C_LIST_ID));
            listName = cursor.getString(cursor.getColumnIndex(DBManager.C_LISTNAME));

            output = String.format("%s \t\t %s \n", id, listName);
            tvListNames.append(output);
            spinnerArray.add(output);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinListNames.setAdapter(adapter);
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.button_create_list:
            {
                EditText text = (EditText)findViewById(R.id.et_list_name);
                String data = text.getText().toString();
                PostToList(data);
                text.setText("");
                PopulateListNames();
                break;
            }
            case R.id.button_delete_list:
            {
                DeleteList();
                break;
            }
        }

    }

    private void DeleteList()
    {
        try
        {
            //String selected = sItems.getSelectedItem().toString();
            //if (selected.equals("what ever the option was")) {
            //}
        }
        catch(Exception e)
        {
            Toast.makeText(this, "Error: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void PostToList(String data)
    {
        try
        {
            database = manager.getReadableDatabase();
            ContentValues value = new ContentValues();

            value.put(DBManager.C_LISTNAME, data);
            database.insert(DBManager.LIST_NAME_TABLE, null, value);
        }
        catch (Exception e)
        {
            Toast.makeText(this, "Error: " + e, Toast.LENGTH_LONG).show();
        }
    }
}
