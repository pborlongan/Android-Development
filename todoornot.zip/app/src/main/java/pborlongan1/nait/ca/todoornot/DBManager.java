package pborlongan1.nait.ca.todoornot;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

/**
 * Created by Pat on 2019-03-07.
 */

public class DBManager extends SQLiteOpenHelper
{
    static final String DB_NAME = "local.db";
    static final int DB_VERSION = 1;

    static final String LIST_NAME_TABLE = "listNames";
    static final String ITEM_TABLE = "listItems";

    static final String C_LIST_ID = BaseColumns._ID;
    static final String C_LISTNAME = "list_name";

    static final String C_ITEM_ID = BaseColumns._ID;
    static final String C_ITEM = "list_item";

    public DBManager(Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database)
    {
        String listTable = "create table " + LIST_NAME_TABLE + " (" + C_LIST_ID + " integer primary key autoincrement, " + C_LISTNAME + " text)";

        database.execSQL(listTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion)
    {
        database.execSQL("drop table if exists " + LIST_NAME_TABLE);
        onCreate(database);
    }
}
