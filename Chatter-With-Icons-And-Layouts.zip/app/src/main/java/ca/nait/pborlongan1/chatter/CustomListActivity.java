package ca.nait.pborlongan1.chatter;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

import static ca.nait.pborlongan1.chatter.R.xml.prefs;

public class CustomListActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener {
    ArrayList<HashMap<String,String>> chatter = new ArrayList<HashMap<String, String>>();
    private static final String TAG = "CustomListActivity";
    SharedPreferences prefs;

    View mainView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list);
        displayChatter();

        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.registerOnSharedPreferenceChangeListener(this);
        mainView = findViewById(R.id.layout_custom_list);
        String bgColor = prefs.getString("main_bg_color", "#ddbbbb");
        mainView.setBackgroundColor(Color.parseColor(bgColor));
    }

    private void displayChatter()
    {
        String[] keys = new String[]{"sender", "date", "message"};
        int[] ids = new int[]{R.id.custom_row_sender, R.id.custom_row_date, R.id.custom_row_message};

        SimpleAdapter adapter = new SimpleAdapter(this, chatter, R.layout.custom_row_layout, keys, ids);
        populateList();
        ListView listView = (ListView)findViewById(R.id.listview_custom);
        listView.setAdapter(adapter);
    }

    private void populateList()
    {
        BufferedReader in = null;

        try
        {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            request.setURI(new URI("http://www.youcode.ca/JitterServlet"));

            HttpResponse response = client.execute(request);
            in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

            String field = "";

            while((field = in.readLine()) != null)
            {
                HashMap<String, String> temp = new HashMap<String, String>();

                temp.put("sender", field);

                field = in.readLine();
                temp.put("message", field);

                field = in.readLine();
                temp.put("date", field);

                chatter.add(temp);
            }

            in.close();
        }
        catch(Exception ex)
        {
            Toast.makeText(this, "Error: " + ex, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.custom_menu_home:
            {
                Intent intent = new Intent(this, ChatterSendActivity.class);
                this.startActivity(intent);

                break;
            }
            case R.id.custom_menu_item_preferences:
            {
                Intent intent = new Intent(this, PrefsActivity.class);
                this.startActivity(intent);

                break;
            }
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = this.getMenuInflater();
        inflater.inflate(R.menu.custom_list_menu, menu);

        return true;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s)
    {
        String bgColor = prefs.getString("main_bg_color", "#ddbbbb");
        mainView.setBackgroundColor(Color.parseColor(bgColor));
    }
}
